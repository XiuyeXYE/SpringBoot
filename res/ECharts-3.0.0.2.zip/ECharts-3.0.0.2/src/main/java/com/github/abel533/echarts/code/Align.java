package com.github.abel533.echarts.code;

/**
 * 图例标记和文本的对齐
 *
 * @author liuzh
 * @since 2016-02-28 16:51
 */
public enum Align {
    auto, left, right, top, bottom
}

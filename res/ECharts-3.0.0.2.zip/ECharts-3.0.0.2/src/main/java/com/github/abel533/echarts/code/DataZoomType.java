package com.github.abel533.echarts.code;

/**
 * @author liuzh
 * @since 2016-03-06 10:27
 */
public enum DataZoomType {
    inside,//所谓『内置』，即内置在坐标系中
    slider,//滑动条型数据区域缩放组件
}

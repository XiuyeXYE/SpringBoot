.. include:: ../../README.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

API Guide
---------

Here is the API reference for `echarts-python` .

.. automodule:: echarts.option
   :members:

.. automodule:: echarts.datastructure
   :members:
   :undoc-members:
